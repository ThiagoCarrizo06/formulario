const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;

app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

const usuarios = [];

app.post('/agregar', (req, res) => {
  const { nombre, apellido } = req.body;
  const persona = { nombre, apellido };
  usuarios.push(persona);
  res.json(persona);
});

app.listen(PORT, () => {
  console.log(`http://localhost:${PORT}`);
});