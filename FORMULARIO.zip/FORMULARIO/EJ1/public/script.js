const form = document.getElementById('form');
const lista = document.getElementById('listaUsuarios');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const nombre = document.getElementById('nombre').value;
  const apellido = document.getElementById('apellido').value;

  const res = await fetch('/agregar', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nombre, apellido })
  });

  const usuario = await res.json();
  const li = document.createElement('li');
  li.textContent = `${usuario.nombre} ${usuario.apellido}`;
  lista.appendChild(li);

  form.reset();
});