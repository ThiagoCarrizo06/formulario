const form = document.getElementById('formulario');
const mensaje = document.getElementById('mensaje');
const lista = document.getElementById('listaPersonas');
const tieneHijos = document.getElementById('tieneHijos');
const cantidadHijos = document.getElementById('cantidadHijos');

// Mostrar campo "cantidad de hijos" si elige "Sí"
tieneHijos.addEventListener('change', () => {
  cantidadHijos.style.display = tieneHijos.value === 'Sí' ? 'block' : 'none';
  if (tieneHijos.value !== 'Sí') cantidadHijos.value = '';
});

form.addEventListener('submit', (e) => {
  e.preventDefault();

  // Validaciones adicionales con JS (ya hay HTML5 también)
  const nombre = document.getElementById('nombre').value.trim();
  const apellido = document.getElementById('apellido').value.trim();
  const edad = parseInt(document.getElementById('edad').value);
  const hijos = tieneHijos.value === 'Sí' ? parseInt(cantidadHijos.value) || 0 : 0;

  if (tieneHijos.value === 'Sí' && hijos <= 0) {
    mostrarMensaje("Por favor, indique la cantidad de hijos.", false);
    return;
  }

  const persona = {
    nombre,
    apellido,
    edad,
    nacimiento: document.getElementById('nacimiento').value,
    sexo: document.getElementById('sexo').value,
    documento: document.getElementById('documento').value,
    estado: document.getElementById('estado').value,
    nacionalidad: document.getElementById('nacionalidad').value,
    telefono: document.getElementById('telefono').value,
    mail: document.getElementById('mail').value,
    hijos
  };

  const li = document.createElement('li');
  li.textContent = `${persona.nombre} ${persona.apellido} - Edad: ${persona.edad} - Email: ${persona.mail}`;
  lista.appendChild(li);

  mostrarMensaje("¡Datos guardados correctamente!", true);
  form.reset();
  cantidadHijos.style.display = "none";
});

function mostrarMensaje(texto, esExito) {
  mensaje.textContent = texto;
  mensaje.style.color = esExito ? 'green' : 'red';
  setTimeout(() => mensaje.textContent = '', 3000);
}