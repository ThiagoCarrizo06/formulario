const form = document.getElementById('form');
const lista = document.getElementById('lista');

form.addEventListener('submit', (e) => {
  e.preventDefault();

  const categoria = document.getElementById('categoria').value;
  const nombre = document.getElementById('nombre').value;
  const descripcion = document.getElementById('descripcion').value;
  const precio = document.getElementById('precio').value;

  const li = document.createElement('li');
  li.textContent = `${categoria}: ${nombre} - ${descripcion} ($${precio})`;
  lista.appendChild(li);

  form.reset();
});